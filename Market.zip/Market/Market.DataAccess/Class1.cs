﻿using System;

namespace Market.DataAccess
{
    public class Class1
    {
    }
}
