﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Market.Migrations
{
    public partial class AddSellerLogoImage : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "SellerLogo",
                table: "Sellers",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SellerLogo",
                table: "Sellers");
        }
    }
}
