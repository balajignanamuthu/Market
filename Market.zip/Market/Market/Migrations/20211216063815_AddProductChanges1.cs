﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Market.Migrations
{
    public partial class AddProductChanges1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DefaultImage",
                table: "Product");

            migrationBuilder.AddColumn<string>(
                name: "ProductImagePath",
                table: "Product",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProductImagePath",
                table: "Product");

            migrationBuilder.AddColumn<int>(
                name: "DefaultImage",
                table: "Product",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
