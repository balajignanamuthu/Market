﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Market.Migrations
{
    public partial class SeedValueforSeller : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Sellers",
                columns: new[] { "SellerID", "SellerEmail", "SellerName" },
                values: new object[] { 1, "Shiva@Kailasam.com", "Shiva" });

            migrationBuilder.InsertData(
                table: "Sellers",
                columns: new[] { "SellerID", "SellerEmail", "SellerName" },
                values: new object[] { 2, "Vishnu@Vaiguntam.com", "Vishnu" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Sellers",
                keyColumn: "SellerID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Sellers",
                keyColumn: "SellerID",
                keyValue: 2);
        }
    }
}
