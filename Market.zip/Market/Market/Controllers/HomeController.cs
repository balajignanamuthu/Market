﻿using Market.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Market.ViewModels;

namespace Market.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly ISellerRepository _sellerRepository;
        private readonly IProductRepository _productRepository;

        private readonly IHostingEnvironment _hostingEnvironment;



        public HomeController(ILogger<HomeController> logger, 
            ISellerRepository sellerRepository,
            IHostingEnvironment hostingEnvironment,
            IProductRepository productRepository
            )
        {
            _logger = logger;
            _hostingEnvironment = hostingEnvironment;


            _sellerRepository = sellerRepository;
            _productRepository = productRepository;

            
        }

        public IActionResult Index()
        {

            var model = new List<Item>();

            model.Add(new Item { ItemId = 0, ItemName = "CBD Tinture", SoldBy = "Erth", ItemDescription = "CBD oil is made from cannabidiol, a non-intoxicating extract of marijuana. It is believed to treat pain, anxiety, and seizures.", ImageSource = "/w3images/CBD-Tincture.jpg" });
            model.Add(new Item { ItemId = 1, ItemName = "CBD Oil", SoldBy = "Lazuras Naturals", ItemDescription = "This quality makes CBD an appealing option for those who are looking for relief from pain and other symptoms without the mind-altering effects of cannabis or other side effects related to some pharmaceutical drugs.", ImageSource = "/w3images/CBD_Oil.jpg" });
            model.Add(new Item { ItemId = 2, ItemName = "CBD Balm", SoldBy = "Pearl CBD", ItemDescription = "In addition to helping with physical pain, CBD balms may be beneficial for certain skin conditions. In fact, the American Academy of Dermatology mentions that topical CBD products show potential for reducing inflammation that can contribute to acne, eczema, and psoriasis.", ImageSource = "/w3images/cbd_balm.jpg" });
            model.Add(new Item { ItemId = 3, ItemName = "Hemp Flower", SoldBy = "InTune", ItemDescription = "Smoking CBD flower can benefits people by reducing pain/inflammation, seizures, anxiety and depression.", ImageSource = "/w3images/Lifter-CBD-flower.jpg" });
            model.Add(new Item { ItemId = 4, ItemName = "CBD Vape Pen", SoldBy = "Long Beach", ItemDescription = "With its legalization in many countries around the world, many people have started to use cannabidiol (CBD) products for its potential medical benefits. CBD users ingest the compound in various ways, including vaping. Some studies suggest that CBD may help treat some chronic conditions, such as anxiety and pain.", ImageSource = "/w3images/Vape.png" });


            model.Add(new Item { ItemId = 5, ItemName = "CBD Vape Pen", SoldBy = "Long Beach", ItemDescription = "With its legalization in many countries around the world, many people have started to use cannabidiol (CBD) products for its potential medical benefits. CBD users ingest the compound in various ways, including vaping. Some studies suggest that CBD may help treat some chronic conditions, such as anxiety and pain.", ImageSource = "/w3images/Vape.png" });
            model.Add(new Item { ItemId = 6, ItemName = "CBD Gummies", SoldBy = "Simple Garden", ItemDescription = "CBD usage can help people overcome anxiety and depression symptoms. Organic CBD gummies are excellent tools for people who have trouble sleeping", ImageSource = "/w3images/CBDGummies.jpeg" });
            model.Add(new Item { ItemId = 7, ItemName = "CBD Tinture", SoldBy = "Erth", ItemDescription = "CBD oil is made from cannabidiol, a non-intoxicating extract of marijuana. It is believed to treat pain, anxiety, and seizures.", ImageSource = "/w3images/CBD-Tincture.jpg" });
            model.Add(new Item { ItemId = 8, ItemName = "CBD Oil", SoldBy = "Lazuras Naturals", ItemDescription = "This quality makes CBD an appealing option for those who are looking for relief from pain and other symptoms without the mind-altering effects of cannabis or other side effects related to some pharmaceutical drugs.", ImageSource = "/w3images/CBD_Oil.jpg" });
            model.Add(new Item { ItemId = 9, ItemName = "CBD Balm", SoldBy = "Pearl CBD", ItemDescription = "In addition to helping with physical pain, CBD balms may be beneficial for certain skin conditions. In fact, the American Academy of Dermatology mentions that topical CBD products show potential for reducing inflammation that can contribute to acne, eczema, and psoriasis.", ImageSource = "/w3images/cbd_balm.jpg" });


            model.Add(new Item { ItemId = 10, ItemName = "Hemp Flower", SoldBy = "InTune", ItemDescription = "Smoking CBD flower can benefits people by reducing pain/inflammation, seizures, anxiety and depression.", ImageSource = "/w3images/Lifter-CBD-flower.jpg" });
            model.Add(new Item { ItemId = 11, ItemName = "CBD Vape Pen", SoldBy = "Long Beach", ItemDescription = "With its legalization in many countries around the world, many people have started to use cannabidiol (CBD) products for its potential medical benefits. CBD users ingest the compound in various ways, including vaping. Some studies suggest that CBD may help treat some chronic conditions, such as anxiety and pain.", ImageSource = "/w3images/Vape.png" });
            model.Add(new Item { ItemId = 12, ItemName = "CBD Gummies", SoldBy = "Simple Garden", ItemDescription = "CBD usage can help people overcome anxiety and depression symptoms. Organic CBD gummies are excellent tools for people who have trouble sleeping", ImageSource = "/w3images/CBDGummies.jpeg" });
            model.Add(new Item { ItemId = 13, ItemName = "CBD Vape Pen", SoldBy = "Long Beach", ItemDescription = "With its legalization in many countries around the world, many people have started to use cannabidiol (CBD) products for its potential medical benefits. CBD users ingest the compound in various ways, including vaping. Some studies suggest that CBD may help treat some chronic conditions, such as anxiety and pain.", ImageSource = "/w3images/Vape.png" });
            model.Add(new Item { ItemId = 14, ItemName = "CBD Oil", SoldBy = "Lazuras Naturals", ItemDescription = "This quality makes CBD an appealing option for those who are looking for relief from pain and other symptoms without the mind-altering effects of cannabis or other side effects related to some pharmaceutical drugs.", ImageSource = "/w3images/CBD_Oil.jpg" });

            return View(model);
        }

        public IActionResult ListItems()
        {
            var model = new List<Item>();

            model.Add(new Item { ItemId = 1, ItemName = "CBD Oil" , SoldBy="Lazuras Naturals", ItemDescription= "This quality makes CBD an appealing option for those who are looking for relief from pain and other symptoms without the mind-altering effects of cannabis or other side effects related to some pharmaceutical drugs.", ImageSource= "/w3images/CBD_Oil.jpg" });
            model.Add(new Item { ItemId = 2, ItemName = "CBD Balm", SoldBy = "Pearl CBD", ItemDescription = "In addition to helping with physical pain, CBD balms may be beneficial for certain skin conditions. In fact, the American Academy of Dermatology mentions that topical CBD products show potential for reducing inflammation that can contribute to acne, eczema, and psoriasis.", ImageSource = "/w3images/cbd_balm.jpg" });
            model.Add(new Item { ItemId = 3, ItemName = "Hemp Flower", SoldBy = "InTune", ItemDescription = "Smoking CBD flower can benefits people by reducing pain/inflammation, seizures, anxiety and depression.", ImageSource = "/w3images/Lifter-CBD-flower.jpg" });
            model.Add(new Item { ItemId = 4, ItemName = "CBD Vape Pen", SoldBy = "Long Beach", ItemDescription = "With its legalization in many countries around the world, many people have started to use cannabidiol (CBD) products for its potential medical benefits. CBD users ingest the compound in various ways, including vaping. Some studies suggest that CBD may help treat some chronic conditions, such as anxiety and pain.", ImageSource = "/w3images/Vape.png" });
            model.Add(new Item { ItemId = 4, ItemName = "CBD Gummies", SoldBy = "Simple Garden", ItemDescription = "CBD usage can help people overcome anxiety and depression symptoms. Organic CBD gummies are excellent tools for people who have trouble sleeping", ImageSource = "/w3images/CBDGummies.jpeg" });
            model.Add(new Item { ItemId = 4, ItemName = "CBD Tinture", SoldBy = "Erth", ItemDescription = "CBD oil is made from cannabidiol, a non-intoxicating extract of marijuana. It is believed to treat pain, anxiety, and seizures.", ImageSource = "/w3images/CBD-Tincture.jpg" });

            return View(model);
        }


        public IActionResult SellersList()
        {
            
            return View(_sellerRepository.GetAll());
        }

        [HttpGet]
        public IActionResult EditSellerProfile(int id)
        {
            Seller SellerTobeEdited =  _sellerRepository.GetByID(id);

            EditSellerProfileViewModel ESP = new EditSellerProfileViewModel
            {
                SellerID = SellerTobeEdited.SellerID,
                SellerName = SellerTobeEdited.SellerName,
                SellerEmail = SellerTobeEdited.SellerEmail,
                ExistingSellerLogo = SellerTobeEdited.SellerLogo
            };

            return View(ESP);
        }

        [HttpPost]
        public IActionResult EditSellerProfile(EditSellerProfileViewModel _seller)
        {

            if (ModelState.IsValid)
            {

                string LogoImageFileName = null;

                if (_seller.SellerLogoImage != null)
                {
                    string UploadFolder = Path.Combine(_hostingEnvironment.WebRootPath, "LogoImages");

                    LogoImageFileName = Guid.NewGuid().ToString() + "_" + _seller.SellerLogoImage.FileName;

                    string LogoImageFullFilePath = Path.Combine(UploadFolder, LogoImageFileName);

                    _seller.SellerLogoImage.CopyTo(new FileStream(LogoImageFullFilePath, FileMode.Create));


                }

                Seller SellerToBeUpdated = new Seller
                {
                    SellerID = _seller.SellerID,
                    SellerName = _seller.SellerName,
                    SellerEmail = _seller.SellerEmail,
                    SellerLogo = LogoImageFileName
                };


                _sellerRepository.Update(SellerToBeUpdated);



                return RedirectToAction("SellersList");
            }

            return View();
        }


        public IActionResult Test()
        {

            return View();
        }


        public IActionResult Test2()
        {

            return View();
        }

        [HttpGet]
        public IActionResult ProductForm()
        {

            return View();
        }



        [HttpPost]
        public IActionResult ProductForm(ProductViewModel _product)
        {


            if (ModelState.IsValid)
            {

                string ProductImageFileName = null;

                if (_product.ProductImage != null)
                {
                    string UploadFolder = Path.Combine(_hostingEnvironment.WebRootPath, "ProductImages");

                    ProductImageFileName = Guid.NewGuid().ToString() + "_" + _product.ProductImage.FileName;

                    string ProductImageFullFilePath = Path.Combine(UploadFolder, ProductImageFileName);

                    _product.ProductImage.CopyTo(new FileStream(ProductImageFullFilePath, FileMode.Create));

                }

                Product newProduct = new Product
                {
                    Name = _product.Name,
                    Description = _product.Description,
                    Brand = _product.Brand,
                    ProductImagePath = ProductImageFileName,
                    Length = _product.Length,
                    Width = _product.Width,
                    Height = _product.Height,
                    Cost = _product.Cost,
                    Quantity = _product.Quantity,
                    UnitOfMeasure = _product.UnitOfMeasure,


                    CreatedBy = 1,
                    CreatedDate = DateTime.Now,
                    UpdatedBy = 1,
                    UpdatedDate = DateTime.Now
                };


                _productRepository.Create(newProduct);
                //return RedirectToAction("details", new { ID = newSeller.SellerID });
            }
            return View();
        }



        [HttpGet]
        public IActionResult RegisterSeller()
        {

            return View();
        }

        [HttpPost]
        public IActionResult RegisterSeller(RegisterSellerViewModel _seller)
        {


            if(ModelState.IsValid)
            {

                string LogoImageFileName = null;

                if(_seller.SellerLogoImage != null)
                {
                    string UploadFolder =  Path.Combine(_hostingEnvironment.WebRootPath , "LogoImages");

                    LogoImageFileName =  Guid.NewGuid().ToString() + "_" + _seller.SellerLogoImage.FileName;

                    string LogoImageFullFilePath =  Path.Combine(UploadFolder, LogoImageFileName);

                    _seller.SellerLogoImage.CopyTo( new FileStream(LogoImageFullFilePath,FileMode.Create));

                }

                Seller newSeller = new Seller
                {
                    SellerName = _seller.SellerName,
                    SellerEmail = _seller.SellerEmail,
                    SellerLogo = LogoImageFileName
                };
                    
                    
                    _sellerRepository.Create(newSeller);
                //return RedirectToAction("details", new { ID = newSeller.SellerID });
            }
            return View();
        }





        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult ItemDetail()
        {
            var model = new Item() { ItemId = 1, ItemName = "CBD Oil", SoldBy = "Lazuras Naturals", ItemDescription = "This quality makes CBD an appealing option for those who are looking for relief from pain and other symptoms without the mind-altering effects of cannabis or other side effects related to some pharmaceutical drugs.", ImageSource = "/w3images/CBD_Oil.jpg" };


            return View(model);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
