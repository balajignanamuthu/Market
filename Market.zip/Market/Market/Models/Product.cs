﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Market.Models
{
    public class Product
    {
        public int ID { get; set; }
        [Required]
        [MaxLength(500, ErrorMessage = "Name cannot exceed 500 characters")]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public string Brand { get; set; }
        
        public Decimal Cost { get; set; }
        
        public Decimal Height { get; set; }
        
        public Decimal Width { get; set; }
        
        public Decimal Length { get; set; }
        
        public Double Quantity { get; set; }
        
        public UnitOfMeasure? UnitOfMeasure { get; set; }

        //[Required]
        //public int AvailableUnits { get; set; }
        public string ProductImagePath { get; set; }



        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        
        

    }
}
