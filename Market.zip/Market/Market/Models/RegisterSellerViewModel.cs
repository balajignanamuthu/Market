﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Market.Models
{
    public class RegisterSellerViewModel
    {
        public int SellerID { get; set; }
        [Required]
        [MaxLength(500, ErrorMessage = "Name cannot exceed 500 characters")]
        public string SellerName { get; set; }
        [Required]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", ErrorMessage = "Invalid Email Format")]
        [Display(Name = "Seller's Business Email")]
        public string SellerEmail { get; set; }
        public IFormFile SellerLogoImage { get; set; }

    }
}
