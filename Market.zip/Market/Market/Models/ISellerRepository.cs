﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Market.Models
{
    public interface ISellerRepository
    {

        Seller Create(Seller New);
        Seller GetByID(int ID);
        Seller Update(Seller Updated);
        Seller Delete(int ID);

        IEnumerable<Seller> GetAll();
    }
}
