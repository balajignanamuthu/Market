﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Market.Models
{
    public class ProductRepository : IProductRepository
    {

        
        private readonly MarketDBContext Context;


        public ProductRepository(MarketDBContext context)
        {
            Context = context;

        }
            public Product Create(Product New)
        {
            Context.Product.Add(New);
            Context.SaveChanges();
            return New;

        }

        public Product Delete(int ID)
        {
            Product ToBeDeleted = Context.Product.Find(ID);
            if (ToBeDeleted != null)
            {
                Context.Product.Remove(ToBeDeleted);
                Context.SaveChanges();
            }
            return ToBeDeleted;
        }

        public IEnumerable<Product> GetAll()
        {
            return Context.Product;
        }

        public Product GetByID(int ID)
        {
            return Context.Product.Find(ID);
        }

        public Product Update(Product Updated)
        {
            var upd = Context.Product.Attach(Updated);
            upd.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Context.SaveChanges();

            return Updated;
        }
    }
}
