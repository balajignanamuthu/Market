﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Market.Models
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Seller>().HasData(
                new Seller
                {
                    SellerID = 1,
                    SellerName = "Shiva",
                    SellerEmail = "Shiva@Kailasam.com"

                },
                new Seller
                {
                    SellerID = 2,
                    SellerName = "Vishnu",
                    SellerEmail = "Vishnu@Vaiguntam.com"

                }
                );
        }
    }
}
