﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Market.Models
{
    public interface IProductRepository
    {

        Product Create(Product New);
        Product GetByID(int ID);
        Product Update(Product Updated);
        Product Delete(int ID);

        IEnumerable<Product> GetAll();
    }
}
