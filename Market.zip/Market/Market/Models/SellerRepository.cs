﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Market.Models
{
    public class SellerRepository : ISellerRepository
    {
        private List<Seller> _sellerList;
        private readonly MarketDBContext Context;

        public SellerRepository(MarketDBContext context )
        {
            Context = context;

            _sellerList = new List<Seller>()
            {
                new Seller() { SellerID =1, SellerName="Amazon", SellerEmail="abcd.efg@xyz.com"},
                new Seller() { SellerID =2, SellerName="Ebay", SellerEmail="abcd.efg@xyz.com"},
                new Seller() { SellerID =3, SellerName="Yahoo", SellerEmail="abcd.efg@xyz.com"}
            };
        }

        public Seller Create(Seller NewSeller)
        {
            Context.Sellers.Add(NewSeller);
            Context.SaveChanges();
            return NewSeller;

            //NewSeller.SellerID = _sellerList.Max(s => s.SellerID) + 1;
            
            //_sellerList.Add(NewSeller);
            //return NewSeller;  


        }

        Seller ISellerRepository.Delete(int SellerID)
        {
            Seller SellerToBeDeleted = Context.Sellers.Find(SellerID);
            if (SellerToBeDeleted != null)
            {
                Context.Sellers.Remove(SellerToBeDeleted);
                Context.SaveChanges();
            }
            return SellerToBeDeleted;
        }

        IEnumerable<Seller> ISellerRepository.GetAll()
        {
           return Context.Sellers;
        }

        Seller ISellerRepository.GetByID(int SellerID)
        {
            return Context.Sellers.Find(SellerID);
        }

        Seller ISellerRepository.Update(Seller UpdatedSeller)
        {
            var updseller = Context.Sellers.Attach(UpdatedSeller);
            updseller.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Context.SaveChanges();

            return UpdatedSeller;
        }
    }
}
