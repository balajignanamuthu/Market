﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Market.Models;
using Microsoft.AspNetCore.Http;

namespace Market.ViewModels
{
    public class ProductViewModel : Product
    {
        
        public int SellerID;
        public IFormFile ProductImage { get; set; }

    }
}
